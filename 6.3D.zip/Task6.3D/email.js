const axios = require('axios');
const md5 = require('md5');
const options = {
    headers: {
        'Content-Type': 'application/json;',
        'Authorization': `Basic 12e54294f8bce873eced5361a19b0ca8-us17`
    }
};
function sub (email, firstName) {
    const
        UniqueId = 'b42442ae0f',
        Key = '12e54294f8bce873eced5361a19b0ca8-us17';
    console.log('sending email')
    const data = {
        'email_address': email,
        'status': 'subscribed',
        'merge_fields': {
            'FNAME': firstName
        }
    }

    axios.post(`https://us17.api.mailchimp.com/3.0/lists/${UniqueId}/members`,
        data,
        options)
        .then((data) => { console.log(data) })
        .catch(e => {
            console.log(e)
        })
}

function event (email, url) {
    const subscriber_hash = md5(email);
    const data = {
        name: 'resetpassword',
        properties: {
            href:url
        }
    };
    axios.post(`https://us17.api.mailchimp.com/3.0/lists/b42442ae0f/members/${subscriber_hash}/events`,
        data,
        options)
        .then((data) => { console.log(data) })
        .catch(e => {
            console.log(e)
        })
}

module.exports = { sub,event }