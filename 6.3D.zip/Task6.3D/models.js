const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  email: {
    type: String,
    unique: true, //字段是否唯一
    required: [true, "Email is required."],
    validate: {
      validator: (email) => {
        return /^([a-zA-Z\d])(\w|\-)+@[a-zA-Z\d]+\.[a-zA-Z]{2,4}$/.test(email);
      },
      message: "The email address must be valid!",
    },
  },
  country: {
    type: String,
    required: [true, "Country is required."],
  },
  firstName: {
    type: String,
    required: [true, "First name is required."],
  },
  lastName: {
    type: String,
    required: [true, "Last name is required."],
  },
  password: {
    type: String,
    minlength: [8, "The password must be at least 8 characters!"],
    required: [true, "Password is required."],
    set(val) {
      return require("bcryptjs").hashSync(val, 10);
    },
  },
  address: {
    type: String,
    required: [true, "Address is required."],
  },
  city: {
    type: String,
    required: [true, "City is required."],
  },
  state: {
    type: String,
    required: [true, "State is required."],
  },
  code: {
    type: String,
  },
  phone: {
    type: String,
    validate: {
      validator: (phone) => {
        return phone == "" || /^(\+?1)?[2-9]\d{2}[2-9](?!11)\d{6}$/.test(phone);
      },
      message: "The mobile phone number must be valid!",
    },
  },
});

const User = mongoose.model("User", UserSchema);
module.exports = { User };
