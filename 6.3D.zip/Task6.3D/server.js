const express = require("express");
const bodyParser = require("body-parser");
const { User } = require("./models");

const mongoose = require("mongoose");
const { static } = require("express");
const { sub, event } = require('./email');
const { OAuth2Client } = require('google-auth-library');
const client = new OAuth2Client('909240747168-kceaurt201p0t2aa93vpdknmhe4veauq.apps.googleusercontent.com');
// connect
// mongodb://username:password@host:port/database
mongoose.connect("mongodb+srv://user:pass@cluster0.705hh.azure.mongodb.net/db?retryWrites=true&w=majority", {
  useCreateIndex: true,
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(static("public"));

// register
app.post("/api/register", async (req, res) => {
  const { body: reqBody } = req;
  const {
    country,
    firstName,
    lastName,
    password,
    password2,
    email,
    phone,
    address,
    city,
    state,
    code,
  } = reqBody;

  if (password !== password2) {
    return res
      .status(400)
      .send("The password must be the same as re-typed one!");
  }

  try {
    const user = await User.create({
      country,
      firstName,
      lastName,
      password,
      email,
      phone,
      address,
      city,
      state,
      code,
    });
    // Return
    sub(email, firstName);
    res.status(302).redirect("/login");
  } catch (error) {
    const err = error.errors;
    if (err) {
      let messages = [];
      for (let key in err) {
        messages.push(err[key].message);
      }

      return res.send(messages.join("-------"));
    } else if (error.message.indexOf("duplicate key error") !== -1) {
      return res.status(400).send("Email already exists.");
    }
  }
});

app.post("/api/login", async (req, res) => {
  const user = await User.findOne({
    email: req.body.email,
  });
  if (!user) {
    return res.status(422).send("The user does not exist!");
  }

  const isPasswordValid = require("bcryptjs").compareSync(
    req.body.password,
    user.password
  );
  if (!isPasswordValid) {
    return res.status(422).send("The password is invalid!");
  }

  res.status(302).redirect("/");
});

app.post('/api/resetpassword', async (req, res) => {
  const user = await User.findOne({
    email: req.body.email,
  });
  if (!user) {
    return res.status(422).send("The user does not exist!");
  }
  event(req.body.email, req.protocol + '://' + req.get('host') + '/changepass.html?id=' + user._id);
  return res.send("A email has been sent");

})

app.post('/api/changepassword', async (req, res) => {
  const { id, password, password2 } = req.body;

  if (password !== password2) {
    return res
      .status(400)
      .send("The password must be the same as re-typed one!");
  }
  const user = await User.updateOne({
    _id: id,
  }, {
    password
  });
  res.redirect('/login')
})

app.post('/api/google', async (req, res) => {
  console.log(req.body)
  try {
    const ticket = await client.verifyIdToken({
      idToken: req.body.idToken,
      audience: '909240747168-kceaurt201p0t2aa93vpdknmhe4veauq.apps.googleusercontent.com',  // Specify the CLIENT_ID of the app that accesses the backend
      // Or, if multiple clients access the backend:
      //[CLIENT_ID_1, CLIENT_ID_2, CLIENT_ID_3]
    });
    console.log(ticket)
    const payload = ticket.getPayload();
    const userid = payload['sub'];
    console.log(userid)
    return res.json({ userid })
  } catch (e) {
    console.log(e)
    res.status(401).send('unauthorized')
  }
})

app.get("/register", (req, res) => {
  res.sendFile(__dirname + "/public/register.html");
});

app.get("/login", (req, res) => {
  res.sendFile(__dirname + "/public/login.html");
});

app.get("/forgotpass", (req, res) => {
  res.sendFile(__dirname + "/public/forgotpass.html");
});


app.get("/", (req, res) => {
  res.send("Hello World!");
});

let port = process.env.PORT || 3001

app.listen(port, () => {
  console.log("http://localhost:" + port);
});
